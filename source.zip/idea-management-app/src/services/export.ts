import * as FileSystem from 'expo-file-system/legacy';
import * as Sharing from 'expo-sharing';
import { strToU8, zipSync } from 'fflate';
import { getDb } from '@/db/database';
import type { Idea } from '@/domain/types';

function bytesToBase64(bytes: Uint8Array) {
  let binary = '';
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) {
    binary += String.fromCharCode(...bytes.subarray(i, Math.min(i + chunk, bytes.length)));
  }
  return globalThis.btoa(binary);
}

function base64ToBytes(base64: string) {
  const binary = globalThis.atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i += 1) bytes[i] = binary.charCodeAt(i);
  return bytes;
}

function safeName(value: string) {
  return value.replace(/[\\/:*?"<>|]+/g, '-').replace(/\s+/g, ' ').trim().slice(0, 80) || 'Untitled idea';
}

function ideaMarkdown(idea: any, blocks: any[], tags: any[]) {
  const lines = [
    `# ${idea.title || 'Untitled idea'}`,
    '',
    `- Stage: ${idea.stage}`,
    `- Created: ${new Date(idea.created_at).toISOString()}`,
    `- Updated: ${new Date(idea.updated_at).toISOString()}`,
    `- Tags: ${tags.map((x) => x.name).join(', ') || '—'}`,
    '',
  ];
  if (idea.summary) lines.push('## Summary', '', idea.summary, '');
  for (const block of blocks) {
    if (block.type === 'text' && block.body_text) {
      lines.push(block.is_original ? '## Original capture' : '## Thought', '', block.body_text, '');
    } else if (block.attachment_id) {
      lines.push(`- ${block.type} attachment: ${block.attachment_id}`);
    }
  }
  if (idea.problem || idea.audience || idea.next_experiment || idea.next_action || idea.done_definition) {
    lines.push('', '## Development', '');
    if (idea.problem) lines.push(`**Problem / opportunity:** ${idea.problem}`, '');
    if (idea.audience) lines.push(`**Who benefits:** ${idea.audience}`, '');
    if (idea.next_experiment) lines.push(`**Smallest test:** ${idea.next_experiment}`, '');
    if (idea.next_action) lines.push(`**Next action:** ${idea.next_action}`, '');
    if (idea.done_definition) lines.push(`**Done looks like:** ${idea.done_definition}`, '');
  }
  return lines.join('\n');
}

export async function exportAllData() {
  const db = await getDb();
  const tables = ['ideas','idea_blocks','idea_events','categories','tags','idea_tags','idea_links','attachments','transcripts','reminders','resurfacing_events','feedback_notes','app_settings'];
  const data: Record<string, unknown[]> = {};
  for (const table of tables) data[table] = await db.getAllAsync(`SELECT * FROM ${table}`);
  const ideas = data.ideas as Idea[];
  const blocks = data.idea_blocks as any[];
  const tags = data.tags as any[];
  const ideaTags = data.idea_tags as any[];
  const attachments = data.attachments as any[];

  const archive: Record<string, Uint8Array> = {};
  archive['ideas-export.json'] = strToU8(JSON.stringify({ exportedAt: new Date().toISOString(), schema: 1, data }, null, 2));

  for (const idea of ideas) {
    const ideaBlocks = blocks.filter((b) => b.idea_id === idea.id);
    const tagIds = ideaTags.filter((it) => it.idea_id === idea.id).map((it) => it.tag_id);
    const ideaTagRows = tags.filter((t) => tagIds.includes(t.id));
    archive[`markdown/${safeName(idea.title || idea.id)}-${idea.id.slice(-6)}.md`] = strToU8(ideaMarkdown(idea, ideaBlocks, ideaTagRows));
  }

  for (const attachment of attachments) {
    try {
      const info = await FileSystem.getInfoAsync(attachment.local_uri);
      if (!info.exists) continue;
      const base64 = await FileSystem.readAsStringAsync(attachment.local_uri, { encoding: FileSystem.EncodingType.Base64 });
      const ext = (attachment.local_uri.split('.').pop() || 'bin').replace(/[^a-zA-Z0-9]/g, '');
      archive[`attachments/${attachment.id}.${ext || 'bin'}`] = base64ToBytes(base64);
    } catch {
      // Missing/unreadable attachments are represented in canonical JSON and do not abort the export.
    }
  }

  const zip = zipSync(archive, { level: 6 });
  const uri = `${FileSystem.cacheDirectory}idea-vault-export-${new Date().toISOString().slice(0,10)}.zip`;
  await FileSystem.writeAsStringAsync(uri, bytesToBase64(zip), { encoding: FileSystem.EncodingType.Base64 });
  if (await Sharing.isAvailableAsync()) await Sharing.shareAsync(uri, { mimeType: 'application/zip', dialogTitle: 'Export Idea Vault' });
  return uri;
}
