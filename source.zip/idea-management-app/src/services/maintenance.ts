import * as FileSystem from 'expo-file-system/legacy';
import { getDb } from '@/db/database';

const THIRTY_DAYS = 30 * 86_400_000;

export async function purgeExpiredTrash() {
  const db = await getDb();
  const cutoff = Date.now() - THIRTY_DAYS;
  const rows = await db.getAllAsync<{ id: string; local_uri: string | null }>(`
    SELECT i.id, a.local_uri
    FROM ideas i
    LEFT JOIN attachments a ON a.idea_id=i.id
    WHERE i.deleted_at IS NOT NULL AND i.deleted_at < ?
  `, cutoff);
  const ids = [...new Set(rows.map((r) => r.id))];
  if (!ids.length) return 0;

  await db.withTransactionAsync(async () => {
    for (const id of ids) {
      await db.runAsync('DELETE FROM idea_fts WHERE idea_id=?', id);
      await db.runAsync('DELETE FROM ideas WHERE id=?', id);
    }
  });

  for (const row of rows) {
    if (!row.local_uri?.startsWith('file://')) continue;
    try { await FileSystem.deleteAsync(row.local_uri, { idempotent: true }); } catch { /* best effort */ }
  }
  return ids.length;
}
