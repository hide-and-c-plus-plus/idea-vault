import { Platform } from 'react-native';
import * as Notifications from 'expo-notifications';
import { getDb } from '@/db/database';
import { createId } from '@/utils/id';

Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldPlaySound: false,
    shouldSetBadge: false,
    shouldShowBanner: true,
    shouldShowList: true,
  }),
});

export async function configureNotificationChannels() {
  if (Platform.OS !== 'android') return;
  await Notifications.setNotificationChannelAsync('reminders', {
    name: 'Idea reminders',
    importance: Notifications.AndroidImportance.DEFAULT,
    vibrationPattern: [0, 120],
    showBadge: false,
  });
  await Notifications.setNotificationChannelAsync('weekly_review', {
    name: 'Weekly review',
    importance: Notifications.AndroidImportance.DEFAULT,
    showBadge: false,
  });
}

async function ensureNotificationPermission() {
  const existing = await Notifications.getPermissionsAsync();
  if (existing.granted) return true;
  const requested = await Notifications.requestPermissionsAsync();
  return requested.granted;
}

export async function scheduleIdeaReminder(ideaId: string, title: string, date: Date) {
  if (!(await ensureNotificationPermission())) throw new Error('Notification permission was not granted.');
  await configureNotificationChannels();
  const notificationId = await Notifications.scheduleNotificationAsync({
    content: {
      title: 'You asked to revisit this idea.',
      body: title,
      data: { url: `/idea/${ideaId}`, ideaId },
    },
    trigger: {
      type: Notifications.SchedulableTriggerInputTypes.DATE,
      date,
      channelId: Platform.OS === 'android' ? 'reminders' : undefined,
    },
  });
  const db = await getDb();
  await db.runAsync(
    'INSERT INTO reminders(id,idea_id,scheduled_at,kind,notification_id) VALUES(?,?,?,?,?)',
    createId('reminder'), ideaId, date.getTime(), 'idea', notificationId,
  );
  return notificationId;
}
