import * as SQLite from 'expo-sqlite';

let databasePromise: Promise<SQLite.SQLiteDatabase> | null = null;

export function getDb() {
  if (!databasePromise) {
    databasePromise = SQLite.openDatabaseAsync('idea-vault.db').then(async (db) => {
      await db.execAsync('PRAGMA journal_mode = WAL; PRAGMA foreign_keys = ON; PRAGMA busy_timeout = 3000;');
      return db;
    });
  }
  return databasePromise;
}
