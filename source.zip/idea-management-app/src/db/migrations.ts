import { getDb } from './database';

const migrations: string[] = [
  `
  CREATE TABLE IF NOT EXISTS schema_meta (version INTEGER NOT NULL);
  INSERT INTO schema_meta(version) SELECT 0 WHERE NOT EXISTS (SELECT 1 FROM schema_meta);

  CREATE TABLE IF NOT EXISTS categories (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    parent_id TEXT NULL REFERENCES categories(id),
    icon TEXT NULL,
    color_token TEXT NULL,
    sort_order INTEGER NOT NULL DEFAULT 0,
    archived_at INTEGER NULL
  );

  CREATE TABLE IF NOT EXISTS ideas (
    id TEXT PRIMARY KEY,
    title TEXT NULL,
    summary TEXT NULL,
    stage TEXT NOT NULL DEFAULT 'spark',
    inbox_state TEXT NOT NULL DEFAULT 'unprocessed',
    primary_category_id TEXT NULL REFERENCES categories(id),
    horizon TEXT NULL,
    potential INTEGER NULL,
    effort INTEGER NULL,
    next_action TEXT NULL,
    done_definition TEXT NULL,
    problem TEXT NULL,
    audience TEXT NULL,
    why_now TEXT NULL,
    next_experiment TEXT NULL,
    risks TEXT NULL,
    created_at INTEGER NOT NULL,
    updated_at INTEGER NOT NULL,
    last_touched_at INTEGER NOT NULL,
    archived_at INTEGER NULL,
    dropped_at INTEGER NULL,
    deleted_at INTEGER NULL,
    source_type TEXT NOT NULL,
    original_capture_id TEXT NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_ideas_updated ON ideas(updated_at DESC);
  CREATE INDEX IF NOT EXISTS idx_ideas_stage ON ideas(stage);
  CREATE INDEX IF NOT EXISTS idx_ideas_inbox ON ideas(inbox_state);
  CREATE INDEX IF NOT EXISTS idx_ideas_category ON ideas(primary_category_id);
  CREATE INDEX IF NOT EXISTS idx_ideas_live ON ideas(deleted_at) WHERE deleted_at IS NULL;

  CREATE TABLE IF NOT EXISTS idea_blocks (
    id TEXT PRIMARY KEY,
    idea_id TEXT NOT NULL REFERENCES ideas(id) ON DELETE CASCADE,
    type TEXT NOT NULL,
    body_text TEXT NULL,
    attachment_id TEXT NULL,
    derived_from_block_id TEXT NULL REFERENCES idea_blocks(id),
    position INTEGER NOT NULL DEFAULT 0,
    created_at INTEGER NOT NULL,
    updated_at INTEGER NOT NULL,
    is_original INTEGER NOT NULL DEFAULT 0
  );
  CREATE INDEX IF NOT EXISTS idx_blocks_idea ON idea_blocks(idea_id, position, created_at);

  CREATE TABLE IF NOT EXISTS idea_events (
    id TEXT PRIMARY KEY,
    idea_id TEXT NOT NULL REFERENCES ideas(id) ON DELETE CASCADE,
    event_type TEXT NOT NULL,
    payload_json TEXT NULL,
    created_at INTEGER NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_events_idea ON idea_events(idea_id, created_at DESC);

  CREATE TABLE IF NOT EXISTS tags (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    normalized_name TEXT NOT NULL UNIQUE,
    color_token TEXT NULL,
    created_at INTEGER NOT NULL
  );
  CREATE TABLE IF NOT EXISTS idea_tags (
    idea_id TEXT NOT NULL REFERENCES ideas(id) ON DELETE CASCADE,
    tag_id TEXT NOT NULL REFERENCES tags(id) ON DELETE CASCADE,
    PRIMARY KEY (idea_id, tag_id)
  );

  CREATE TABLE IF NOT EXISTS idea_links (
    id TEXT PRIMARY KEY,
    source_idea_id TEXT NOT NULL REFERENCES ideas(id) ON DELETE CASCADE,
    target_idea_id TEXT NOT NULL REFERENCES ideas(id) ON DELETE CASCADE,
    link_type TEXT NOT NULL,
    note TEXT NULL,
    created_at INTEGER NOT NULL
  );

  CREATE TABLE IF NOT EXISTS attachments (
    id TEXT PRIMARY KEY,
    idea_id TEXT NOT NULL REFERENCES ideas(id) ON DELETE CASCADE,
    block_id TEXT NULL REFERENCES idea_blocks(id) ON DELETE SET NULL,
    kind TEXT NOT NULL,
    local_uri TEXT NOT NULL,
    mime_type TEXT NULL,
    byte_size INTEGER NULL,
    duration_ms INTEGER NULL,
    sha256 TEXT NULL,
    created_at INTEGER NOT NULL
  );

  CREATE TABLE IF NOT EXISTS transcripts (
    id TEXT PRIMARY KEY,
    attachment_id TEXT NOT NULL REFERENCES attachments(id) ON DELETE CASCADE,
    text TEXT NOT NULL,
    language TEXT NULL,
    provider TEXT NULL,
    segments_json TEXT NULL,
    created_at INTEGER NOT NULL
  );

  CREATE TABLE IF NOT EXISTS reminders (
    id TEXT PRIMARY KEY,
    idea_id TEXT NOT NULL REFERENCES ideas(id) ON DELETE CASCADE,
    scheduled_at INTEGER NOT NULL,
    kind TEXT NOT NULL DEFAULT 'idea',
    snoozed_until INTEGER NULL,
    notification_id TEXT NULL,
    completed_at INTEGER NULL
  );
  CREATE INDEX IF NOT EXISTS idx_reminders_due ON reminders(scheduled_at, completed_at);

  CREATE TABLE IF NOT EXISTS resurfacing_events (
    id TEXT PRIMARY KEY,
    idea_id TEXT NOT NULL REFERENCES ideas(id) ON DELETE CASCADE,
    reason TEXT NOT NULL,
    shown_at INTEGER NOT NULL,
    action TEXT NULL,
    snoozed_until INTEGER NULL
  );

  CREATE TABLE IF NOT EXISTS feedback_notes (
    id TEXT PRIMARY KEY,
    idea_id TEXT NOT NULL REFERENCES ideas(id) ON DELETE CASCADE,
    person_name TEXT NULL,
    body TEXT NOT NULL,
    created_at INTEGER NOT NULL
  );

  CREATE TABLE IF NOT EXISTS drafts (
    id TEXT PRIMARY KEY,
    body_text TEXT NOT NULL DEFAULT '',
    mode TEXT NOT NULL DEFAULT 'text',
    attachment_uri TEXT NULL,
    metadata_json TEXT NULL,
    updated_at INTEGER NOT NULL
  );

  CREATE TABLE IF NOT EXISTS app_settings (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
  );

  CREATE VIRTUAL TABLE IF NOT EXISTS idea_fts USING fts5(
    idea_id UNINDEXED,
    title,
    summary,
    body,
    tokenize='unicode61 remove_diacritics 2'
  );
  `,
];

const seedSql = `
INSERT OR IGNORE INTO categories(id,name,parent_id,color_token,sort_order) VALUES
('cat_product','Product / Business',NULL,'accent',10),
('cat_technology','Technology',NULL,'accent',20),
('cat_creative','Creative',NULL,'warning',30),
('cat_learning','Learning / Research',NULL,'success',40),
('cat_personal','Personal / Life',NULL,'success',50),
('cat_writing','Writing / Content',NULL,'warning',60),
('cat_problem','Problem / Opportunity',NULL,'danger',70),
('cat_experiment','Experiment',NULL,'accent',80),
('cat_unsorted','Random / Unsorted',NULL,'textMuted',90);
`;

export async function runMigrations() {
  const db = await getDb();
  const row = await db.getFirstAsync<{ version: number }>('SELECT version FROM schema_meta LIMIT 1').catch(() => null);
  let version = row?.version ?? 0;
  while (version < migrations.length) {
    await db.withTransactionAsync(async () => {
      await db.execAsync(migrations[version]!);
      await db.runAsync('UPDATE schema_meta SET version = ?', version + 1);
    });
    version += 1;
  }
  await db.execAsync(seedSql);
}
