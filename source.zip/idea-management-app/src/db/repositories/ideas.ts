import * as FileSystem from 'expo-file-system/legacy';
import { getDb } from '../database';
import type { Category, Idea, IdeaBlock, IdeaDetail, IdeaStage } from '@/domain/types';
import { createId } from '@/utils/id';
import { normalizeTag, provisionalTitle } from '@/utils/text';

const IDEA_SELECT = `
SELECT i.*, c.name AS category_name,
  COALESCE((SELECT body_text FROM idea_blocks b WHERE b.idea_id=i.id AND b.type='text' ORDER BY b.position, b.created_at LIMIT 1), '') AS snippet
FROM ideas i
LEFT JOIN categories c ON c.id=i.primary_category_id`;

async function logEvent(ideaId: string, type: string, payload: unknown = null) {
  const db = await getDb();
  await db.runAsync(
    'INSERT INTO idea_events(id,idea_id,event_type,payload_json,created_at) VALUES(?,?,?,?,?)',
    createId('evt'), ideaId, type, payload == null ? null : JSON.stringify(payload), Date.now(),
  );
}

async function syncFts(ideaId: string) {
  const db = await getDb();
  const idea = await db.getFirstAsync<any>('SELECT title,summary,problem,audience,why_now,next_experiment,risks,next_action,done_definition FROM ideas WHERE id=?', ideaId);
  if (!idea) return;
  const bodies = await db.getAllAsync<{ body: string }>(`
    SELECT body_text AS body FROM idea_blocks WHERE idea_id=? AND body_text IS NOT NULL
    UNION ALL
    SELECT t.text AS body FROM transcripts t JOIN attachments a ON a.id=t.attachment_id WHERE a.idea_id=?
    UNION ALL
    SELECT tg.name AS body FROM tags tg JOIN idea_tags it ON it.tag_id=tg.id WHERE it.idea_id=?
  `, ideaId, ideaId, ideaId);
  const structured=[idea.problem,idea.audience,idea.why_now,idea.next_experiment,idea.risks,idea.next_action,idea.done_definition].filter(Boolean);
  await db.runAsync('DELETE FROM idea_fts WHERE idea_id=?', ideaId);
  await db.runAsync('INSERT INTO idea_fts(idea_id,title,summary,body) VALUES(?,?,?,?)', ideaId, idea.title ?? '', idea.summary ?? '', [...bodies.map((x) => x.body),...structured].join('\n'));
}

export async function createIdeaFromCapture(input: { text?: string; audioUri?: string; audioDurationMs?: number; sourceType?: string }) {
  const db = await getDb();
  const now = Date.now();
  const ideaId = createId('idea');
  const originalBlockId = createId('block');
  const text = input.text?.trim() ?? '';
  const title = text ? provisionalTitle(text) : input.audioUri ? 'Voice idea' : 'Untitled idea';

  await db.withTransactionAsync(async () => {
    await db.runAsync(`INSERT INTO ideas(
      id,title,stage,inbox_state,created_at,updated_at,last_touched_at,source_type,original_capture_id
    ) VALUES(?,?,?,?,?,?,?,?,?)`, ideaId, title, 'spark', 'unprocessed', now, now, now, input.sourceType ?? (input.audioUri ? 'voice' : 'text'), originalBlockId);

    if (text) {
      await db.runAsync(`INSERT INTO idea_blocks(id,idea_id,type,body_text,position,created_at,updated_at,is_original)
        VALUES(?,?,?,?,?,?,?,1)`, originalBlockId, ideaId, 'text', text, 0, now, now);
    } else {
      await db.runAsync(`INSERT INTO idea_blocks(id,idea_id,type,body_text,position,created_at,updated_at,is_original)
        VALUES(?,?,?,?,?,?,?,1)`, originalBlockId, ideaId, 'text', '', 0, now, now);
    }

    if (input.audioUri) {
      const attachmentId = createId('att');
      const audioBlockId = createId('block');
      await db.runAsync(`INSERT INTO idea_blocks(id,idea_id,type,body_text,attachment_id,position,created_at,updated_at,is_original)
        VALUES(?,?,?,?,?,?,?,?,1)`, audioBlockId, ideaId, 'audio', null, attachmentId, 1, now, now);
      await db.runAsync(`INSERT INTO attachments(id,idea_id,block_id,kind,local_uri,mime_type,duration_ms,created_at)
        VALUES(?,?,?,?,?,?,?,?)`, attachmentId, ideaId, audioBlockId, 'audio', input.audioUri, 'audio/mp4', input.audioDurationMs ?? null, now);
    }
  });
  await logEvent(ideaId, 'created', { source: input.sourceType ?? 'capture' });
  await syncFts(ideaId);
  return ideaId;
}

export async function listIdeas(options: { stage?: IdeaStage; inbox?: 'unprocessed' | 'processed'; limit?: number; includeArchived?: boolean } = {}) {
  const db = await getDb();
  const where = ['i.deleted_at IS NULL'];
  const args: unknown[] = [];
  if (!options.includeArchived) where.push("i.stage <> 'archived'");
  if (options.stage) { where.push('i.stage=?'); args.push(options.stage); }
  if (options.inbox) { where.push('i.inbox_state=?'); args.push(options.inbox); }
  args.push(options.limit ?? 50);
  return db.getAllAsync<Idea>(`${IDEA_SELECT} WHERE ${where.join(' AND ')} ORDER BY i.updated_at DESC LIMIT ?`, ...args);
}

export async function listActiveIdeas() {
  return listIdeas({ stage: 'active', limit: 5 });
}

export async function listInboxIdeas(limit = 100) {
  return listIdeas({ inbox: 'unprocessed', limit });
}

export async function listRecentIdeas(limit = 5) {
  return listIdeas({ limit });
}

export async function getIdea(id: string): Promise<IdeaDetail | null> {
  const db = await getDb();
  const idea = await db.getFirstAsync<Idea>(`${IDEA_SELECT} WHERE i.id=? LIMIT 1`, id);
  if (!idea) return null;
  const blocks = await db.getAllAsync<IdeaBlock>('SELECT * FROM idea_blocks WHERE idea_id=? ORDER BY position,created_at', id);
  const tags = await db.getAllAsync<any>('SELECT t.* FROM tags t JOIN idea_tags it ON it.tag_id=t.id WHERE it.idea_id=? ORDER BY t.name', id);
  const attachments = await db.getAllAsync<any>('SELECT * FROM attachments WHERE idea_id=? ORDER BY created_at', id);
  return { ...idea, blocks, tags, attachments };
}

export async function markProcessed(id: string) {
  const db = await getDb();
  const now = Date.now();
  await db.runAsync("UPDATE ideas SET inbox_state='processed', updated_at=?, last_touched_at=? WHERE id=?", now, now, id);
  await logEvent(id, 'inbox_processed');
}

export async function updateIdea(id: string, patch: Partial<Pick<Idea,
  'title' | 'summary' | 'stage' | 'primary_category_id' | 'horizon' | 'potential' | 'effort' | 'next_action' | 'done_definition' | 'problem' | 'audience' | 'why_now' | 'next_experiment' | 'risks'>>) {
  const db = await getDb();
  const entries = Object.entries(patch).filter(([, v]) => v !== undefined);
  if (!entries.length) return;
  const now = Date.now();
  const set = entries.map(([k]) => `${k}=?`).join(',');
  const values = entries.map(([, v]) => v) as (string | number | null)[];
  await db.runAsync(`UPDATE ideas SET ${set},updated_at=?,last_touched_at=? WHERE id=?`, ...values, now, now, id);
  if (patch.stage) {
    if (patch.stage === 'dropped') await db.runAsync('UPDATE ideas SET dropped_at=? WHERE id=?', now, id);
    if (patch.stage === 'archived') await db.runAsync('UPDATE ideas SET archived_at=? WHERE id=?', now, id);
    await logEvent(id, 'stage_changed', { stage: patch.stage });
  } else {
    await logEvent(id, 'idea_updated', { fields: entries.map(([k]) => k) });
  }
  await syncFts(id);
}

export async function addTextBlock(ideaId: string, text: string) {
  const db = await getDb();
  const now = Date.now();
  const id = createId('block');
  const position = await db.getFirstAsync<{ next: number }>('SELECT COALESCE(MAX(position),-1)+1 AS next FROM idea_blocks WHERE idea_id=?', ideaId);
  await db.withTransactionAsync(async () => {
    await db.runAsync(`INSERT INTO idea_blocks(id,idea_id,type,body_text,position,created_at,updated_at,is_original)
      VALUES(?,?,?,?,?,?,?,0)`, id, ideaId, 'text', text.trim(), position?.next ?? 0, now, now);
    await db.runAsync('UPDATE ideas SET updated_at=?,last_touched_at=? WHERE id=?', now, now, ideaId);
  });
  await logEvent(ideaId, 'block_added', { blockId: id, type: 'text' });
  await syncFts(ideaId);
}

export async function addAttachmentBlock(ideaId: string, input: { type: 'image' | 'file' | 'audio'; uri: string; mimeType?: string | null; durationMs?: number | null; isOriginal?: boolean }) {
  const db = await getDb();
  const now = Date.now();
  const blockId = createId('block');
  const attachmentId = createId('att');
  const position = await db.getFirstAsync<{ next: number }>('SELECT COALESCE(MAX(position),-1)+1 AS next FROM idea_blocks WHERE idea_id=?', ideaId);
  await db.withTransactionAsync(async () => {
    await db.runAsync(`INSERT INTO idea_blocks(id,idea_id,type,body_text,attachment_id,position,created_at,updated_at,is_original)
      VALUES(?,?,?,?,?,?,?,?,?)`, blockId, ideaId, input.type, null, attachmentId, position?.next ?? 0, now, now, input.isOriginal ? 1 : 0);
    await db.runAsync(`INSERT INTO attachments(id,idea_id,block_id,kind,local_uri,mime_type,duration_ms,created_at)
      VALUES(?,?,?,?,?,?,?,?)`, attachmentId, ideaId, blockId, input.type, input.uri, input.mimeType ?? null, input.durationMs ?? null, now);
    await db.runAsync('UPDATE ideas SET updated_at=?,last_touched_at=? WHERE id=?', now, now, ideaId);
  });
  await logEvent(ideaId, 'block_added', { blockId, type: input.type });
}

export async function setTags(ideaId: string, names: string[]) {
  const db = await getDb();
  const normalized = [...new Set(names.map(normalizeTag).filter(Boolean))].slice(0, 20);
  await db.withTransactionAsync(async () => {
    await db.runAsync('DELETE FROM idea_tags WHERE idea_id=?', ideaId);
    for (const value of normalized) {
      let tag = await db.getFirstAsync<{ id: string }>('SELECT id FROM tags WHERE normalized_name=?', value);
      if (!tag) {
        const id = createId('tag');
        await db.runAsync('INSERT INTO tags(id,name,normalized_name,created_at) VALUES(?,?,?,?)', id, value, value, Date.now());
        tag = { id };
      }
      await db.runAsync('INSERT OR IGNORE INTO idea_tags(idea_id,tag_id) VALUES(?,?)', ideaId, tag.id);
    }
  });
  await logEvent(ideaId, 'tags_changed', { tags: normalized });
  await syncFts(ideaId);
}

export async function listCategories() {
  const db = await getDb();
  return db.getAllAsync<Category>('SELECT * FROM categories WHERE archived_at IS NULL ORDER BY sort_order,name');
}

export async function searchIdeas(query: string, filters: { stage?: string; categoryId?: string; tag?: string; sourceType?: string; horizon?: string; since?: number; includeArchived?: boolean } = {}) {
  const db = await getDb();
  const where = ['i.deleted_at IS NULL'];
  const args: unknown[] = [];
  if (!filters.includeArchived) where.push("i.stage <> 'archived'");
  if (filters.stage) { where.push('i.stage=?'); args.push(filters.stage); }
  if (filters.categoryId) { where.push('i.primary_category_id=?'); args.push(filters.categoryId); }
  if (filters.tag) { where.push('EXISTS (SELECT 1 FROM idea_tags fit JOIN tags ft ON ft.id=fit.tag_id WHERE fit.idea_id=i.id AND ft.normalized_name LIKE ?)'); args.push(`${normalizeTag(filters.tag)}%`); }
  if (filters.sourceType) { where.push('i.source_type=?'); args.push(filters.sourceType); }
  if (filters.horizon) { where.push('i.horizon=?'); args.push(filters.horizon); }
  if (filters.since) { where.push('i.created_at>=?'); args.push(filters.since); }
  const trimmed = query.trim();
  if (!trimmed) {
    return db.getAllAsync<Idea>(`${IDEA_SELECT} WHERE ${where.join(' AND ')} ORDER BY i.updated_at DESC LIMIT 100`, ...args);
  }
  const tokens = trimmed.replace(/["'()^:*+-]/g, ' ').split(/\s+/).filter(Boolean).slice(0, 8);
  const fts = tokens.map((x) => `"${x.replace(/"/g, '""')}"*`).join(' AND ');
  return db.getAllAsync<Idea>(`
    SELECT i.*, c.name AS category_name,
      snippet(idea_fts, 3, '‹', '›', '…', 14) AS snippet
    FROM idea_fts
    JOIN ideas i ON i.id=idea_fts.idea_id
    LEFT JOIN categories c ON c.id=i.primary_category_id
    WHERE idea_fts MATCH ? AND ${where.join(' AND ')}
    ORDER BY bm25(idea_fts, 0, 8, 4, 1), i.updated_at DESC LIMIT 100
  `, fts, ...args);
}

export async function softDeleteIdea(id: string) {
  const db = await getDb();
  const now = Date.now();
  await db.runAsync('UPDATE ideas SET deleted_at=?,updated_at=? WHERE id=?', now, now, id);
  await logEvent(id, 'trashed');
}

export async function listTrash() {
  const db = await getDb();
  return db.getAllAsync<Idea>(`${IDEA_SELECT} WHERE i.deleted_at IS NOT NULL ORDER BY i.deleted_at DESC`);
}

export async function restoreIdea(id: string) {
  const db = await getDb();
  await db.runAsync('UPDATE ideas SET deleted_at=NULL,updated_at=? WHERE id=?', Date.now(), id);
  await logEvent(id, 'restored');
}

export async function permanentlyDeleteIdea(id: string) {
  const db = await getDb();
  const files = await db.getAllAsync<{ local_uri: string | null }>('SELECT local_uri FROM attachments WHERE idea_id=?', id);
  await db.withTransactionAsync(async () => {
    await db.runAsync('DELETE FROM idea_fts WHERE idea_id=?', id);
    await db.runAsync('DELETE FROM ideas WHERE id=?', id);
  });
  for (const file of files) {
    if (!file.local_uri?.startsWith('file://')) continue;
    try { await FileSystem.deleteAsync(file.local_uri, { idempotent: true }); } catch { /* best effort */ }
  }
}

export async function saveDraft(id: string, body: string, mode = 'text', attachmentUri: string | null = null, metadataJson: string | null = null) {
  const db = await getDb();
  await db.runAsync(`INSERT INTO drafts(id,body_text,mode,attachment_uri,metadata_json,updated_at) VALUES(?,?,?,?,?,?)
    ON CONFLICT(id) DO UPDATE SET body_text=excluded.body_text,mode=excluded.mode,attachment_uri=excluded.attachment_uri,metadata_json=excluded.metadata_json,updated_at=excluded.updated_at`,
    id, body, mode, attachmentUri, metadataJson, Date.now());
}

export async function getDraft(id: string) {
  const db = await getDb();
  return db.getFirstAsync<{ id: string; body_text: string; mode: string; attachment_uri: string | null; metadata_json: string | null; updated_at: number }>('SELECT * FROM drafts WHERE id=?', id);
}

export async function clearDraft(id: string) {
  const db = await getDb();
  await db.runAsync('DELETE FROM drafts WHERE id=?', id);
}
