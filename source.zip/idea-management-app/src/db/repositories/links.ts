import { getDb } from '../database';
import { createId } from '@/utils/id';
import type { LinkType } from '@/domain/types';

export interface IdeaConnection { id: string; other_id: string; other_title: string | null; link_type: LinkType; direction: 'outgoing'|'incoming'; note: string | null }

export async function addIdeaLink(sourceId: string, targetId: string, linkType: LinkType, note: string | null = null) {
  if (sourceId === targetId) throw new Error('An idea cannot link to itself.');
  const db = await getDb();
  const existing = await db.getFirstAsync<{id:string}>('SELECT id FROM idea_links WHERE source_idea_id=? AND target_idea_id=? AND link_type=?', sourceId,targetId,linkType);
  if (existing) return existing.id;
  const id=createId('link');
  await db.runAsync('INSERT INTO idea_links(id,source_idea_id,target_idea_id,link_type,note,created_at) VALUES(?,?,?,?,?,?)',id,sourceId,targetId,linkType,note,Date.now());
  await db.runAsync('INSERT INTO idea_events(id,idea_id,event_type,payload_json,created_at) VALUES(?,?,?,?,?)',createId('evt'),sourceId,'link_added',JSON.stringify({targetId,linkType}),Date.now());
  return id;
}

export async function listConnections(ideaId: string) {
  const db=await getDb();
  return db.getAllAsync<IdeaConnection>(`
    SELECT l.id,l.target_idea_id AS other_id,t.title AS other_title,l.link_type,'outgoing' AS direction,l.note
    FROM idea_links l JOIN ideas t ON t.id=l.target_idea_id WHERE l.source_idea_id=?
    UNION ALL
    SELECT l.id,l.source_idea_id AS other_id,s.title AS other_title,l.link_type,'incoming' AS direction,l.note
    FROM idea_links l JOIN ideas s ON s.id=l.source_idea_id WHERE l.target_idea_id=?
    ORDER BY other_title`,ideaId,ideaId);
}

export async function removeIdeaLink(id: string) { const db=await getDb(); await db.runAsync('DELETE FROM idea_links WHERE id=?',id); }
