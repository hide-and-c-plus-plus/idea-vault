import React, { useEffect, useRef, useState } from 'react';
import { Alert, KeyboardAvoidingView, Platform, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { router, useLocalSearchParams } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { AudioModule, RecordingPresets, setAudioModeAsync, useAudioRecorder, useAudioRecorderState } from 'expo-audio';
import * as Haptics from 'expo-haptics';
import { useIncomingShare } from 'expo-sharing';
import { createIdeaFromCapture, addAttachmentBlock, clearDraft, getDraft, saveDraft } from '@/db/repositories/ideas';
import { captureImageAttachment, importFileAttachment, importImageAttachment, persistSharedAttachment } from '@/services/attachments';
import { Button } from '@/components/ui/Button';
import { Caption, H1, Secondary } from '@/components/ui/Typography';
import { useDataChange } from '@/state/DataChangeContext';
import { colors, radius, spacing } from '@/theme/tokens';

type AttachmentKind = 'image' | 'file' | null;
const DRAFT_ID = 'quick-capture';

export default function CaptureScreen() {
  const params = useLocalSearchParams<{ mode?: string }>();
  const { bump } = useDataChange();
  const { sharedPayloads, resolvedSharedPayloads, isResolving, clearSharedPayloads } = useIncomingShare();
  const sharedProcessed = useRef(false);
  const [text,setText]=useState('');
  const [audioUri,setAudioUri]=useState<string|null>(null);
  const [attachment,setAttachment]=useState<{uri:string;mimeType:string|null;kind:AttachmentKind;name?:string}|null>(null);
  const [saving,setSaving]=useState(false);
  const [restored,setRestored]=useState(false);
  const inputRef=useRef<TextInput>(null);
  const recorder=useAudioRecorder({ ...RecordingPresets.HIGH_QUALITY, directory: 'document' });
  const recorderState=useAudioRecorderState(recorder,250);

  useEffect(()=>{(async()=>{const draft=await getDraft(DRAFT_ID);if(draft){setText(draft.body_text);let metadata:any=null;try{metadata=draft.metadata_json?JSON.parse(draft.metadata_json):null}catch{}if(metadata){setAudioUri(metadata.audioUri??null);setAttachment(metadata.attachment??null);}else if(draft.attachment_uri){if(draft.mode==='audio')setAudioUri(draft.attachment_uri);else setAttachment({uri:draft.attachment_uri,mimeType:null,kind:draft.mode==='image'?'image':'file'});}}setRestored(true);setTimeout(()=>inputRef.current?.focus(),120);if(params.mode==='audio') setTimeout(()=>startRecording(),250);})()},[]);


  useEffect(()=>{if(!restored||params.shared!=='1'||isResolving||sharedProcessed.current||(!sharedPayloads.length&&!resolvedSharedPayloads.length))return;sharedProcessed.current=true;(async()=>{try{
    const sharedText=sharedPayloads.filter(p=>p.shareType==='text'||p.shareType==='url').map(p=>p.value||'').filter(Boolean).join('\n');
    if(sharedText)setText(current=>current.trim()?`${current}\n\n${sharedText}`:sharedText);
    const media=resolvedSharedPayloads.find(p=>p.contentUri&&(p.contentType==='image'||p.contentType==='file'||p.contentType==='audio'));
    if(media?.contentUri){const saved=await persistSharedAttachment(media.contentUri,media.originalName,media.contentType==='image'?'jpg':media.contentType==='audio'?'m4a':'bin');if(media.contentType==='audio')setAudioUri(saved);else setAttachment({uri:saved,mimeType:media.contentMimeType??null,kind:media.contentType==='image'?'image':'file',name:media.originalName??undefined});}
    clearSharedPayloads();
  }catch(e){Alert.alert('Could not import shared content',String(e))}})()},[restored,params.shared,isResolving,sharedPayloads,resolvedSharedPayloads,clearSharedPayloads]);

  useEffect(()=>{if(!restored)return;const id=setTimeout(()=>saveDraft(DRAFT_ID,text,audioUri?'audio':attachment?.kind??'text',audioUri??attachment?.uri??null,JSON.stringify({audioUri,attachment})).catch(()=>{}),350);return()=>clearTimeout(id)},[text,audioUri,attachment,restored]);

  const startRecording=async()=>{try{const permission=await AudioModule.requestRecordingPermissionsAsync();if(!permission.granted){Alert.alert('Microphone permission','Voice capture needs microphone permission. Text capture remains available.');return;}await setAudioModeAsync({playsInSilentMode:true,allowsRecording:true,allowsBackgroundRecording:true});setAudioUri(null);await recorder.prepareToRecordAsync({ ...RecordingPresets.HIGH_QUALITY, directory: 'document' });recorder.record();}catch(e){Alert.alert('Could not start recording',String(e))}};
  const stopRecording=async()=>{try{await recorder.stop();const uri=recorder.uri;if(uri){setAudioUri(uri);await saveDraft(DRAFT_ID,text,'audio',uri,JSON.stringify({audioUri:uri,attachment}));}}catch(e){Alert.alert('Could not stop recording',String(e))}};

  const chooseImage=async()=>{try{const result=await importImageAttachment();if(result)setAttachment({...result,kind:'image'});}catch(e){Alert.alert('Could not attach image',String(e))}};
  const takePhoto=async()=>{try{const result=await captureImageAttachment();if(result)setAttachment({...result,kind:'image'});}catch(e){Alert.alert('Could not use camera',String(e))}};
  const chooseFile=async()=>{try{const result=await importFileAttachment();if(result)setAttachment({...result,kind:'file'});}catch(e){Alert.alert('Could not attach file',String(e))}};

  const save=async(again=false)=>{if(!text.trim()&&!audioUri&&!attachment&&!recorderState.isRecording){Alert.alert('Nothing to save','Type a thought, record audio, or attach something first.');return;}setSaving(true);try{let finalAudioUri=audioUri;if(recorderState.isRecording){await recorder.stop();finalAudioUri=recorder.uri??null;if(finalAudioUri)setAudioUri(finalAudioUri);}const ideaId=await createIdeaFromCapture({text,audioUri:finalAudioUri??undefined,audioDurationMs:recorderState.durationMillis,sourceType:params.shared==='1'?'share_sheet':finalAudioUri?'voice':'quick_capture'});if(attachment?.kind)await addAttachmentBlock(ideaId,{type:attachment.kind,uri:attachment.uri,mimeType:attachment.mimeType,isOriginal:true});await clearDraft(DRAFT_ID);await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);bump();if(again){setText('');setAudioUri(null);setAttachment(null);inputRef.current?.focus();}else router.back();}catch(e){Alert.alert('Could not save idea',String(e))}finally{setSaving(false)}};

  const seconds=Math.floor((recorderState.durationMillis||0)/1000);
  return <SafeAreaView style={styles.safe}><KeyboardAvoidingView style={styles.flex} behavior={Platform.OS==='ios'?'padding':undefined}><View style={styles.header}><Pressable accessibilityLabel="Close capture" onPress={()=>router.back()} style={styles.icon}><Text style={styles.iconText}>×</Text></Pressable><H1>Quick capture</H1><View style={styles.icon}/></View>
    <TextInput ref={inputRef} accessibilityLabel="Idea text" value={text} onChangeText={setText} multiline placeholder="What are you thinking?" placeholderTextColor={colors.textMuted} style={styles.editor} textAlignVertical="top" />
    {recorderState.isRecording?<View style={styles.recording}><View style={styles.dot}/><Secondary>Recording • {seconds}s • safe to background</Secondary></View>:audioUri?<View style={styles.attachment}><Secondary>● Voice recording attached</Secondary><Pressable onPress={()=>setAudioUri(null)}><Caption>Remove</Caption></Pressable></View>:null}
    {attachment?<View style={styles.attachment}><Secondary>{attachment.kind==='image'?'▧ Image':'▤ File'} attached{attachment.name?` • ${attachment.name}`:''}</Secondary><Pressable onPress={()=>setAttachment(null)}><Caption>Remove</Caption></Pressable></View>:null}
    <View style={styles.tools}><Pressable accessibilityLabel={recorderState.isRecording?'Stop recording':'Record voice'} onPress={recorderState.isRecording?stopRecording:startRecording} style={[styles.tool,recorderState.isRecording&&styles.toolActive]}><Text style={styles.toolGlyph}>{recorderState.isRecording?'■':'●'}</Text><Caption>{recorderState.isRecording?'Stop':'Voice'}</Caption></Pressable><Pressable accessibilityLabel="Attach image" onPress={chooseImage} style={styles.tool}><Text style={styles.toolGlyph}>▧</Text><Caption>Image</Caption></Pressable><Pressable accessibilityLabel="Take photo" onPress={takePhoto} style={styles.tool}><Text style={styles.toolGlyph}>◉</Text><Caption>Camera</Caption></Pressable><Pressable accessibilityLabel="Attach file" onPress={chooseFile} style={styles.tool}><Text style={styles.toolGlyph}>＋</Text><Caption>File</Caption></Pressable></View>
    <View style={styles.bottom}><Button label="Save + New" variant="secondary" disabled={saving} onPress={()=>save(true)} style={{flex:1}}/><Button label="Save" loading={saving} onPress={()=>save(false)} style={{flex:1}}/></View>
  </KeyboardAvoidingView></SafeAreaView>;
}
const styles=StyleSheet.create({safe:{flex:1,backgroundColor:colors.bg},flex:{flex:1},header:{height:64,paddingHorizontal:spacing.lg,flexDirection:'row',alignItems:'center',justifyContent:'space-between'},icon:{width:48,height:48,alignItems:'center',justifyContent:'center'},iconText:{color:colors.textPrimary,fontSize:30},editor:{flex:1,color:colors.textPrimary,fontSize:20,lineHeight:30,padding:spacing.xl,minHeight:240},recording:{marginHorizontal:spacing.lg,borderRadius:radius.md,padding:spacing.md,backgroundColor:colors.surfaceRaised,flexDirection:'row',alignItems:'center',gap:8},dot:{width:10,height:10,borderRadius:5,backgroundColor:colors.danger},attachment:{marginHorizontal:spacing.lg,marginTop:8,minHeight:48,borderRadius:radius.md,paddingHorizontal:spacing.md,backgroundColor:colors.surfaceRaised,borderWidth:1,borderColor:colors.border,flexDirection:'row',alignItems:'center',justifyContent:'space-between'},tools:{flexDirection:'row',gap:8,padding:spacing.lg,flexWrap:'wrap'},tool:{width:72,minHeight:64,borderRadius:radius.md,borderWidth:1,borderColor:colors.border,backgroundColor:colors.surface,alignItems:'center',justifyContent:'center',gap:2},toolActive:{borderColor:colors.danger},toolGlyph:{color:colors.textPrimary,fontSize:19},bottom:{flexDirection:'row',gap:spacing.md,paddingHorizontal:spacing.lg,paddingBottom:spacing.md}});
