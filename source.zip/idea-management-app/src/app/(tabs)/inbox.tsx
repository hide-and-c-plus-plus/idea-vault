import React, { useEffect, useState } from 'react';
import { Alert, StyleSheet, View } from 'react-native';
import { Screen } from '@/components/ui/Screen';
import { Display, Secondary } from '@/components/ui/Typography';
import { Button } from '@/components/ui/Button';
import { IdeaCard } from '@/components/idea/IdeaCard';
import { listInboxIdeas, markProcessed } from '@/db/repositories/ideas';
import type { Idea } from '@/domain/types';
import { useDataChange } from '@/state/DataChangeContext';
import { spacing } from '@/theme/tokens';

export default function InboxScreen(){const{epoch,bump}=useDataChange();const[items,setItems]=useState<Idea[]>([]);const[busy,setBusy]=useState(false);useEffect(()=>{listInboxIdeas().then(setItems)},[epoch]);
const processFive=async()=>{setBusy(true);try{for(const idea of items.slice(0,5)) await markProcessed(idea.id);bump();}catch(e){Alert.alert('Could not process Inbox',String(e))}finally{setBusy(false)}};
return <Screen><View style={styles.head}><View><Display>Inbox</Display><Secondary>{items.length ? `${items.length} unprocessed capture${items.length===1?'':'s'}. No rush.`:'Everything is safely processed.'}</Secondary></View>{items.length?<Button label="Process 5" onPress={processFive} loading={busy} variant="secondary"/>:null}</View><View style={styles.list}>{items.map(i=><View key={i.id} style={{gap:8}}><IdeaCard idea={i}/><Button label="Mark processed" variant="ghost" onPress={async()=>{await markProcessed(i.id);bump();}}/></View>)}</View></Screen>}
const styles=StyleSheet.create({head:{paddingTop:spacing.sm,gap:spacing.md},list:{gap:spacing.md,marginTop:spacing.xl}});
