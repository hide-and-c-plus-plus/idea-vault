import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { Tabs, router } from 'expo-router';
import { colors } from '@/theme/tokens';

const tabIcon = (glyph: string) => ({ color }: { color: string }) => <Text style={{ color, fontSize: 17 }}>{glyph}</Text>;
export default function TabsLayout() {
  return <View style={{flex:1}}><Tabs screenOptions={{headerShown:false,tabBarStyle:{backgroundColor:colors.surface,borderTopColor:colors.border,height:72,paddingBottom:10,paddingTop:8},tabBarActiveTintColor:colors.textPrimary,tabBarInactiveTintColor:colors.textMuted,tabBarLabelStyle:{fontSize:11}}}>
    <Tabs.Screen name="index" options={{title:'Home',tabBarIcon:tabIcon('⌂')}}/>
    <Tabs.Screen name="inbox" options={{title:'Inbox',tabBarIcon:tabIcon('▣')}}/>
    <Tabs.Screen name="library" options={{title:'Library',tabBarIcon:tabIcon('⌕')}}/>
    <Tabs.Screen name="review" options={{title:'Review',tabBarIcon:tabIcon('◇')}}/>
  </Tabs><Pressable accessibilityRole="button" accessibilityLabel="Capture an idea" onPress={()=>router.push('/capture' as any)} style={({pressed})=>[styles.fab,pressed&&{transform:[{scale:.96}]}]}><Text style={styles.plus}>＋</Text></Pressable></View>;
}
const styles=StyleSheet.create({fab:{position:'absolute',alignSelf:'center',bottom:43,width:58,height:58,borderRadius:29,backgroundColor:colors.accent,alignItems:'center',justifyContent:'center',borderWidth:5,borderColor:colors.bg},plus:{fontSize:29,color:colors.textPrimary,lineHeight:32}});
