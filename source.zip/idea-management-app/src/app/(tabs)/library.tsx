import React, { useEffect, useState } from 'react';
import { Pressable, StyleSheet, TextInput, View } from 'react-native';
import { Screen } from '@/components/ui/Screen';
import { Display, Secondary } from '@/components/ui/Typography';
import { Chip } from '@/components/ui/Chip';
import { IdeaCard } from '@/components/idea/IdeaCard';
import { listCategories, searchIdeas } from '@/db/repositories/ideas';
import type { Category, Horizon, Idea, IdeaStage } from '@/domain/types';
import { useDataChange } from '@/state/DataChangeContext';
import { colors, radius, spacing } from '@/theme/tokens';

const stages: Array<IdeaStage | 'all'> = ['all', 'spark', 'exploring', 'promising', 'active', 'parked', 'done', 'dropped'];
const horizons: Array<Horizon | 'all'> = ['all', 'now', 'soon', 'someday', 'evergreen', 'time-sensitive'];
const sources = ['all', 'quick_capture', 'voice', 'share_sheet'] as const;
const dateRanges = [
  { label: 'Any time', days: 0 },
  { label: '7d', days: 7 },
  { label: '30d', days: 30 },
  { label: '1y', days: 365 },
] as const;

export default function LibraryScreen() {
  const { epoch } = useDataChange();
  const [q, setQ] = useState('');
  const [stage, setStage] = useState<IdeaStage | 'all'>('all');
  const [horizon, setHorizon] = useState<Horizon | 'all'>('all');
  const [source, setSource] = useState<(typeof sources)[number]>('all');
  const [categoryId, setCategoryId] = useState<string | null>(null);
  const [tag, setTag] = useState('');
  const [days, setDays] = useState(0);
  const [includeArchived, setIncludeArchived] = useState(false);
  const [showFilters, setShowFilters] = useState(false);
  const [categories, setCategories] = useState<Category[]>([]);
  const [items, setItems] = useState<Idea[]>([]);

  useEffect(() => { listCategories().then(setCategories); }, []);
  useEffect(() => {
    const id = setTimeout(() => {
      searchIdeas(q, {
        stage: stage === 'all' ? undefined : stage,
        horizon: horizon === 'all' ? undefined : horizon,
        sourceType: source === 'all' ? undefined : source,
        categoryId: categoryId ?? undefined,
        tag: tag.trim() || undefined,
        since: days ? Date.now() - days * 86_400_000 : undefined,
        includeArchived,
      }).then(setItems);
    }, 120);
    return () => clearTimeout(id);
  }, [q, stage, horizon, source, categoryId, tag, days, includeArchived, epoch]);

  const activeFilterCount = [stage !== 'all', horizon !== 'all', source !== 'all', !!categoryId, !!tag.trim(), days > 0, includeArchived].filter(Boolean).length;

  return <Screen>
    <View style={{ paddingTop: spacing.sm }}><Display>Library</Display><Secondary>Full-text search across titles, blocks, development fields, tags, and transcripts.</Secondary></View>
    <TextInput accessibilityLabel="Search ideas" value={q} onChangeText={setQ} placeholder="Search your ideas…" placeholderTextColor={colors.textMuted} autoCapitalize="none" style={styles.search}/>
    <Pressable accessibilityRole="button" onPress={() => setShowFilters((v) => !v)} style={styles.filterButton}><Secondary>{showFilters ? 'Hide filters' : 'Filters'}{activeFilterCount ? ` • ${activeFilterCount} active` : ''}</Secondary></Pressable>
    {showFilters ? <View style={styles.filterPanel}>
      <Secondary>Stage</Secondary><View style={styles.chips}>{stages.map((s) => <Chip key={s} label={s} selected={stage === s} onPress={() => setStage(s)}/>)}</View>
      <Secondary>Horizon</Secondary><View style={styles.chips}>{horizons.map((s) => <Chip key={s} label={s} selected={horizon === s} onPress={() => setHorizon(s)}/>)}</View>
      <Secondary>Capture type</Secondary><View style={styles.chips}>{sources.map((s) => <Chip key={s} label={s.replaceAll('_', ' ')} selected={source === s} onPress={() => setSource(s)}/>)}</View>
      <Secondary>Created</Secondary><View style={styles.chips}>{dateRanges.map((r) => <Chip key={r.label} label={r.label} selected={days === r.days} onPress={() => setDays(r.days)}/>)}</View>
      <Secondary>Primary category</Secondary><View style={styles.chips}><Chip label="all" selected={!categoryId} onPress={() => setCategoryId(null)}/>{categories.map((c) => <Chip key={c.id} label={c.name} selected={categoryId === c.id} onPress={() => setCategoryId(c.id)}/>)}</View>
      <Secondary>Tag starts with</Secondary><TextInput accessibilityLabel="Filter by tag" value={tag} onChangeText={setTag} placeholder="e.g. android" placeholderTextColor={colors.textMuted} style={styles.smallInput}/>
      <View style={styles.chips}><Chip label="Include archive" selected={includeArchived} onPress={() => setIncludeArchived((v) => !v)}/></View>
    </View> : null}
    <Secondary style={{ marginVertical: spacing.md }}>{items.length} result{items.length === 1 ? '' : 's'}</Secondary>
    <View style={styles.list}>{items.map((i) => <IdeaCard key={i.id} idea={i}/>)}</View>
  </Screen>;
}

const styles = StyleSheet.create({
  search: { height: 52, borderRadius: radius.md, borderWidth: 1, borderColor: colors.border, backgroundColor: colors.surfaceRaised, color: colors.textPrimary, paddingHorizontal: spacing.lg, fontSize: 16, marginTop: spacing.xl },
  filterButton: { minHeight: 48, justifyContent: 'center', alignItems: 'flex-start' },
  filterPanel: { backgroundColor: colors.surface, borderRadius: radius.lg, borderWidth: 1, borderColor: colors.border, padding: spacing.lg, gap: spacing.sm },
  chips: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  smallInput: { height: 48, borderRadius: radius.md, borderWidth: 1, borderColor: colors.border, backgroundColor: colors.surfaceRaised, color: colors.textPrimary, paddingHorizontal: spacing.md, fontSize: 15 },
  list: { gap: spacing.md },
});
