import React, { useEffect, useState } from 'react';
import { Pressable, StyleSheet, View } from 'react-native';
import { router } from 'expo-router';
import { Screen } from '@/components/ui/Screen';
import { Display, Secondary } from '@/components/ui/Typography';
import { Section } from '@/components/ui/Section';
import { CaptureLauncher } from '@/components/capture/CaptureLauncher';
import { IdeaCard } from '@/components/idea/IdeaCard';
import { listActiveIdeas, listRecentIdeas } from '@/db/repositories/ideas';
import { getResurfacedIdeas, type ResurfacedIdea, snoozeResurfaced } from '@/db/repositories/resurfacing';
import type { Idea } from '@/domain/types';
import { useDataChange } from '@/state/DataChangeContext';
import { colors, spacing } from '@/theme/tokens';

export default function HomeScreen() {
  const { epoch, bump } = useDataChange();
  const [active,setActive]=useState<Idea[]>([]); const [recent,setRecent]=useState<Idea[]>([]); const [resurfaced,setResurfaced]=useState<ResurfacedIdea[]>([]);
  useEffect(()=>{(async()=>{setActive(await listActiveIdeas());setRecent(await listRecentIdeas(5));setResurfaced(await getResurfacedIdeas(3));})()},[epoch]);
  return <Screen><View style={styles.header}><View><Display>Your ideas</Display><Secondary>A calm place for thoughts worth keeping.</Secondary></View><Pressable accessibilityLabel="Settings" onPress={()=>router.push('/settings' as any)} style={styles.icon}><Secondary>⚙</Secondary></Pressable></View>
    <View style={{marginTop:spacing.xl}}><CaptureLauncher/></View>
    <Section title="Focus" subtitle="Up to five active ideas">{active.length ? active.slice(0,3).map(i=><IdeaCard key={i.id} idea={i}/>) : <Secondary>No active focus right now. Promising ideas can wait safely.</Secondary>}</Section>
    <Section title="Worth another look" subtitle="Up to three, never a guilt queue">{resurfaced.length ? resurfaced.map(i=><IdeaCard key={i.id} idea={i} reason={i.reason} actions={<Pressable onPress={async()=>{await snoozeResurfaced(i.id,7);bump();}} style={styles.small}><Secondary>Snooze 7d</Secondary></Pressable>}/>) : <Secondary>Nothing needs your attention. Capture when something arrives.</Secondary>}</Section>
    <Section title="Recent">{recent.map(i=><IdeaCard key={i.id} idea={i}/>)}</Section>
  </Screen>;
}
const styles=StyleSheet.create({header:{paddingTop:spacing.sm,flexDirection:'row',justifyContent:'space-between',alignItems:'center',gap:spacing.lg},icon:{width:48,height:48,borderRadius:24,borderWidth:1,borderColor:colors.border,alignItems:'center',justifyContent:'center'},small:{minHeight:40,justifyContent:'center',paddingHorizontal:8}});
