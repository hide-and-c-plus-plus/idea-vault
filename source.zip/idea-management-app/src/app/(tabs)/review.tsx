import React, { useEffect, useState } from 'react';
import { StyleSheet, View } from 'react-native';
import { Screen } from '@/components/ui/Screen';
import { Display, H2, Secondary } from '@/components/ui/Typography';
import { Button } from '@/components/ui/Button';
import { IdeaCard } from '@/components/idea/IdeaCard';
import { getReviewStats } from '@/db/repositories/stats';
import { getResurfacedIdeas } from '@/db/repositories/resurfacing';
import { listActiveIdeas, listInboxIdeas, markProcessed, updateIdea } from '@/db/repositories/ideas';
import type { Idea } from '@/domain/types';
import { useDataChange } from '@/state/DataChangeContext';
import { colors, radius, spacing } from '@/theme/tokens';

export default function ReviewScreen(){const{epoch,bump}=useDataChange();const[step,setStep]=useState(0);const[stats,setStats]=useState<any>({});const[inbox,setInbox]=useState<Idea[]>([]);const[resurface,setResurface]=useState<any[]>([]);const[active,setActive]=useState<Idea[]>([]);
useEffect(()=>{(async()=>{setStats(await getReviewStats());setInbox((await listInboxIdeas(5)));setResurface(await getResurfacedIdeas(3));setActive(await listActiveIdeas())})()},[epoch,step]);
const next=()=>setStep(s=>Math.min(4,s+1));
return <Screen><View style={styles.top}><View><Display>Weekly review</Display><Secondary>{step===0?'Five minutes, only if useful.':step<4?`${step} of 4`:'Complete'}</Secondary></View><View style={styles.progress}><View style={[styles.bar,{width:`${Math.max(8,step/4*100)}%` as any}]}/></View></View>
{step===0?<View style={styles.panel}><H2>A light reset</H2><Secondary>{stats.inbox||0} Inbox • {stats.promising||0} promising • {stats.active||0} active • {stats.dormant||0} dormant</Secondary><Secondary>Process a few captures, revisit a few ideas, then protect your active capacity.</Secondary><Button label="Begin review" onPress={next}/></View>:null}
{step===1?<View style={styles.panel}><H2>1. Inbox cleanup</H2>{inbox.length?inbox.map(i=><View key={i.id} style={{gap:8}}><IdeaCard idea={i}/><Button label="Processed" variant="secondary" onPress={async()=>{await markProcessed(i.id);bump()}}/></View>):<Secondary>Inbox is clear.</Secondary>}<Button label="Continue" onPress={next}/></View>:null}
{step===2?<View style={styles.panel}><H2>2. Revisit</H2>{resurface.length?resurface.map(i=><IdeaCard key={i.id} idea={i} reason={i.reason}/>):<Secondary>Nothing needs resurfacing.</Secondary>}<Button label="Continue" onPress={next}/></View>:null}
{step===3?<View style={styles.panel}><H2>3. Active capacity</H2><Secondary>Keep at most 3–5 ideas prominent. Parking is safe, not failure.</Secondary>{active.map(i=><View key={i.id} style={{gap:8}}><IdeaCard idea={i}/><Button label="Park for now" variant="ghost" onPress={async()=>{await updateIdea(i.id,{stage:'parked'});bump()}}/></View>)}<Button label="Continue" onPress={next}/></View>:null}
{step===4?<View style={styles.panel}><H2>Review complete</H2><Secondary>Your ideas are still here. Nothing else is required.</Secondary><Button label="Done" onPress={()=>setStep(0)}/></View>:null}
</Screen>}
const styles=StyleSheet.create({top:{paddingTop:spacing.sm,gap:spacing.md},progress:{height:4,borderRadius:radius.pill,overflow:'hidden',backgroundColor:colors.surfaceRaised},bar:{height:'100%',backgroundColor:colors.accent},panel:{marginTop:spacing.xl,gap:spacing.md}});
