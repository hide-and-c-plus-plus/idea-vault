import React, { useEffect, useState } from 'react';
import { ActivityIndicator, StyleSheet, Text, View } from 'react-native';
import { Stack, router } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import * as Notifications from 'expo-notifications';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { runMigrations } from '@/db/migrations';
import { configureNotificationChannels } from '@/services/notifications';
import { DataChangeProvider } from '@/state/DataChangeContext';
import { purgeExpiredTrash } from '@/services/maintenance';
import { colors } from '@/theme/tokens';

function useNotificationObserver() {
  useEffect(() => {
    const redirect = (notification: Notifications.Notification) => {
      const url = notification.request.content.data?.url;
      if (typeof url === 'string') router.push(url as any);
    };
    const response = Notifications.getLastNotificationResponse();
    if (response?.notification) redirect(response.notification);
    const sub = Notifications.addNotificationResponseReceivedListener((next) => redirect(next.notification));
    return () => sub.remove();
  }, []);
}

export default function RootLayout() {
  const [ready, setReady] = useState(false);
  const [error, setError] = useState<Error | null>(null);
  useNotificationObserver();
  useEffect(() => {
    (async () => {
      try {
        await runMigrations();
        await configureNotificationChannels();
        await purgeExpiredTrash();
        setReady(true);
      } catch (e) { setError(e as Error); }
    })();
  }, []);

  if (!ready) return <View style={styles.loading}><StatusBar style="light"/>{error ? <><Text style={styles.errorTitle}>Could not open Idea Vault</Text><Text style={styles.errorBody}>{error.message}</Text></> : <ActivityIndicator color={colors.accent}/>}</View>;
  return <SafeAreaProvider><DataChangeProvider><StatusBar style="light"/><Stack screenOptions={{ headerShown:false, contentStyle:{backgroundColor:colors.bg}, animation:'fade' }}><Stack.Screen name="(tabs)"/><Stack.Screen name="capture" options={{presentation:'modal',animation:'slide_from_bottom'}}/><Stack.Screen name="idea/[id]"/><Stack.Screen name="idea/[id]/develop"/><Stack.Screen name="idea/[id]/reminder"/><Stack.Screen name="idea/[id]/link"/><Stack.Screen name="settings/index"/><Stack.Screen name="settings/trash"/></Stack></DataChangeProvider></SafeAreaProvider>;
}
const styles=StyleSheet.create({loading:{flex:1,backgroundColor:colors.bg,alignItems:'center',justifyContent:'center',padding:24,gap:12},errorTitle:{color:colors.textPrimary,fontSize:18,fontWeight:'600',textAlign:'center'},errorBody:{color:colors.textSecondary,fontSize:14,textAlign:'center'}});
