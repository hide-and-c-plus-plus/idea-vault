import React from 'react';
import { ScrollView, StyleSheet, View, type ScrollViewProps, type ViewStyle } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { colors, spacing } from '@/theme/tokens';

export function Screen({ children, scroll = true, contentStyle, ...props }: ScrollViewProps & { scroll?: boolean; contentStyle?: ViewStyle }) {
  const content = scroll ? (
    <ScrollView keyboardShouldPersistTaps="handled" contentContainerStyle={[styles.content, contentStyle]} {...props}>{children}</ScrollView>
  ) : <View style={[styles.content, styles.flex, contentStyle]}>{children}</View>;
  return <SafeAreaView style={styles.safe} edges={['top','left','right']}>{content}</SafeAreaView>;
}

const styles = StyleSheet.create({ safe: { flex: 1, backgroundColor: colors.bg }, content: { paddingHorizontal: spacing.lg, paddingBottom: 120 }, flex: { flex: 1 } });
