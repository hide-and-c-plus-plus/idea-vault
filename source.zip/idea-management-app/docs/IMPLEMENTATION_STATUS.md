# Implementation status

This source tree implements the local-first Android MVP rather than the post-MVP roadmap.

## Implemented MVP core

- Expo SDK 57 development-build/prebuild setup with Expo Router.
- Local SQLite source of truth, WAL mode, FTS5, migrations, append-only events, draft recovery, 30-day Trash purge.
- Text, voice, camera/image and file capture; Save + New; immutable original capture blocks.
- Android inbound single-item share handling for text, URL, image, audio and files through `expo-sharing`.
- Inbox processing, stages, categories, tags, horizons, explicit idea links/backlinks.
- Idea timeline, audio playback, development prompts, reminders and notification deep links.
- Full-text filtered Library search, heuristic resurfacing with snooze, and four-step weekly review.
- Canonical JSON + per-idea Markdown + original attachments ZIP export.
- AI service boundary with a no-op implementation; all core workflows remain offline and AI-independent.

## Deliberately left as native hardening / post-MVP

- SQLCipher key lifecycle and migration, biometric/PIN app lock, attachment encryption.
- Launcher shortcuts, home-screen widget and Quick Settings tile.
- Remote/on-device transcription provider, semantic search and AI suggestions.
- Cloud backup/sync, Projects, OCR/PDF indexing, graph view and collaboration.

`expo-sqlite` is explicitly configured with FTS enabled and SQLCipher disabled until a real Keystore-backed key lifecycle is added; enabling SQLCipher without that lifecycle would create a false sense of security.
