# Native Android integration points

The JavaScript/Expo MVP is functional after prebuild. Android inbound sharing is already wired through the Expo SDK 57 `expo-sharing` config plugin and `+native-intent.ts`; shared media is copied into app-private storage before use.

These items remain for the native hardening phase:

1. **App shortcuts** — declare New idea, Record idea and Search shortcuts, each deep-linking to `ideavault://capture`, `ideavault://capture?mode=audio`, and `ideavault://library`.
2. **Widget** — Glance/AppWidgetProvider for Capture and optional revisit card.
3. **SQLCipher** — replace the default SQLite driver after validating migration/export behavior. Keep the DB key in Android Keystore; do not store it in JS or AsyncStorage.
4. **Biometric/PIN lock** — gate UI on foreground using Android BiometricPrompt / secure-store-backed key material. Do not pretend this encrypts unencrypted attachments.
5. **Attachment encryption** — only if the threat model requires protection beyond the Android app sandbox.

Expo SDK 57 targets Android API 36 and Android 7+; verify final Play requirements before release.
