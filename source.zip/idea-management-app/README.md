# Idea Vault — local-first idea management MVP

A build-ready Expo SDK 57 / React Native 0.86 Android app implementing the core capture → preserve → organize → revisit → develop loop from the supplied product specification.

## Included

- Expo Router tab shell and modal capture flow
- SQLite source of truth with migrations, indexes, FTS5, append-only events and draft recovery
- Instant text capture with autosave (350 ms), Save and Save + New
- Voice recording in Quick Capture using `expo-audio`, persistent document storage, plus image/camera/file attachments
- Inbox processing / triage
- Idea detail with immutable Original Capture section, chronological blocks, stage/category/tag editing, development fields and soft-delete/archive
- Full-text Library search with stage, category, tag, source, horizon, date and archive filters
- Home focus, resurfacing heuristics, recent ideas
- Four-step weekly review
- Local reminder scheduling/deep-link payloads
- JSON + Markdown + original-attachment ZIP export and system share sheet
- Trash restore / permanent delete
- Dark design system and 48dp targets
- AI boundary via `NoopAIService` (core workflows never depend on AI)

## Run

Requires Node 22.13+ for Expo SDK 57.

```bash
npm install
npx expo install --fix
npx expo prebuild
npx expo run:android
```

The project includes `expo-dev-client` and intentionally uses a development build / prebuild workflow rather than Expo Go.

## Notes on Android-native scope

The in-app recording flow is implemented and `expo-audio` is configured for background recording. Android shows the required foreground-service notification when background recording is active.

Inbound Android sharing is configured through Expo SDK 57's `expo-sharing` share extension support. Shared text/URLs and supported files route into Quick Capture, and imported media is copied into app-private storage before the share payload is cleared.

Launcher shortcuts, home-screen widgets, a Quick Settings tile, SQLCipher and a biometric/PIN gate remain explicit native hardening/integration points tied to the final application ID and threat model. See `docs/NATIVE_ANDROID.md`.

For an exact implemented-vs-post-MVP breakdown, see `docs/IMPLEMENTATION_STATUS.md`.

## Data ownership

No account, network API, analytics SDK, remote AI, or cloud sync is used. The app works offline. SQLite and app-private files are canonical; export is always available.
